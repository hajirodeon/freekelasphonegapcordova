<?php
echo '<h1>
Belajar PHP, SQL, dan MYSQL

</h1>

<hr>


<ul>
<li>
<a href="latihan1.php">latihan1 : Buka Tutup Koneksi Mysql</a> 
</li>

<li>
<a href="latihan2.php">latihan2 : Membuat Database</a> 
</li>

<li>
<a href="latihan2i.php">latihan2i : Membuat Table</a> 
</li>

<li>
<a href="latihan3.php">latihan3 : Menghapus Table </a> 
</li>

<li>
<a href="latihan4.php">latihan4 : Insert Tambah Data </a> 
</li>

<li>
<a href="latihan5.php">latihan5 : Menampilkan Data </a> 
</li>

<li>
<a href="latihan6.php">latihan6 : Cara Update Data </a> 
</li>


<li>
<a href="latihan7.php">latihan7 : Cara Hapus Data</a> 
</li>


</ul>';



?>
